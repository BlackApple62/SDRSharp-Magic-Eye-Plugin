The files in this archive will add an old-style Magic Eye, or else "Cat's Eye"
to SDR# software (www.airspy.com).
Please follow the instructions in the text file MagicLine.txt
It is compiled as 32bit platform, with .NET Framework version 4.6.
Will not run on SDR# versions older than 

The Plug-in is written in a clean programming style and is guaranteed to be
virus/trojan/malware free.
This plugin is donated for free to the huge SDR# users community.
As such, I assume no responsibility for any problems the use of this plugin may cause.
You are invited for costructive comments and suggestions.
Any reasonable request might be fulfilled based on my spare time, be patient.

Enjoy!